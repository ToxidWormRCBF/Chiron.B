ChironR

Version: Chiron.B
Filetype: Executable
Danger lvl: Middle
Malware type: FMV Trojan
Made by: ToxidWorm
Language: C++
Compatibility: Windows 7 and above
Archive password: ChironRemade